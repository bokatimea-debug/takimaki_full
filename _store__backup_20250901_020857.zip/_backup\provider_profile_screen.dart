﻿import 'package:flutter/material.dart';
import '../utils/profile_photo_loader.dart';

class ProviderProfileScreen extends StatefulWidget {
  const ProviderProfileScreen({super.key});
  @override
  State<ProviderProfileScreen> createState() => _S();
}

class _S extends State<ProviderProfileScreen> {
  ImageProvider? _photo;
  String _intro = '';
  String _wd = '—', _we = '—';

  @override
  void initState(){ super.initState(); _load(); }
  Future<void> _load() async {
    _photo = await ProfilePhotoLoader.load('provider');
    if (!mounted) return;
    setState((){});
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('Szolgáltató profil')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            CircleAvatar(radius: 48, backgroundImage: _photo, child: _photo==null? const Icon(Icons.person, size:48):null),
            const SizedBox(height: 12),
            if(_intro.isNotEmpty)...[
              Align(alignment: Alignment.centerLeft, child: Text('Bemutatkozás', style: Theme.of(context).textTheme.titleMedium)),
              const SizedBox(height: 4),
              Align(alignment: Alignment.centerLeft, child: Text(_intro)),
              const SizedBox(height: 12),
            ],
            Align(alignment: Alignment.centerLeft, child: Text('Általános elérhetőség', style: Theme.of(context).textTheme.titleMedium)),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Hétköznap'), Text(_wd)]),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Hétvége'), Text(_we)]),
            const Spacer(),
            FilledButton(onPressed: ()=> Navigator.pushNamed(context, '/provider/edit').then((_){_load();}), child: const Text('Profil szerkesztése')),
            const SizedBox(height: 10),
            OutlinedButton(onPressed: ()=> Navigator.pushNamed(context, '/provider/services'), child: const Text('Szolgáltatásaim')),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: ()=> Navigator.pushNamed(context, '/offers'), child: const Text('Beérkezett ajánlatkérések')),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: ()=> Navigator.pushNamed(context, '/chat'), child: const Text('Üzenetek')),
          ],
        ),
      ),
    );
  }
}
