#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/workspace/scratch/783a106c3b16/build_env_107/flutter"
export "FLUTTER_APPLICATION_PATH=/workspace/scratch/783a106c3b16/release_107/source/takimaki_full"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/workspace/scratch/783a106c3b16/release_107/source/takimaki_full/ios/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.7"
export "FLUTTER_BUILD_NUMBER=8"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
