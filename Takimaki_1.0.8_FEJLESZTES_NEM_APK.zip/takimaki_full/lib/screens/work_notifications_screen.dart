import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/local_marketplace_store.dart';
import '../utils/work_schedule.dart';
import '../widgets/taki_app_bar.dart';

class WorkNotificationsScreen extends StatefulWidget {
  const WorkNotificationsScreen({super.key});
  @override
  State<WorkNotificationsScreen> createState() =>
      _WorkNotificationsScreenState();
}

class _WorkNotificationsScreenState extends State<WorkNotificationsScreen> {
  List<Map<String, dynamic>> _notices = [];
  String _role = 'customer';
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('active_role') ?? 'customer';
    final notices =
        (jsonDecode(prefs.getString('workflow_notifications') ?? '[]') as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .where(
              (n) =>
                  n['role'] == role &&
                  !(DateTime.tryParse(n['at'].toString())
                          ?.isAfter(DateTime.now()) ??
                      true),
            )
            .toList()
          ..sort((a, b) => b['at'].toString().compareTo(a['at'].toString()));
    if (mounted)
      setState(() {
        _role = role;
        _notices = notices;
      });
  }

  Future<void> _open(Map<String, dynamic> notice) async {
    final works = _role == 'provider'
        ? await LocalMarketplaceStore.providerOrders()
        : await LocalMarketplaceStore.customerOrders();
    final work = works
        .where((w) => WorkSchedule.id(w) == notice['request_id'])
        .firstOrNull;
    if (!mounted) return;
    if (work != null) {
      await Navigator.pushNamed(
        context,
        '/order/details',
        arguments: {...work, 'view_role': _role},
      );
    } else {
      await Navigator.pushNamed(
        context,
        _role == 'provider' ? '/provider/requests' : '/offers',
        arguments: {'request_id': notice['request_id']},
      );
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: TakiAppBar(title: const Text('Munkaértesítések')),
    body: SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            if (_notices.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Még nincs értesítésed.'),
              ),
            for (final notice in _notices)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.notifications_outlined),
                  title: Text(notice['title'].toString()),
                  subtitle: Text(notice['body'].toString()),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _open(notice),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}
