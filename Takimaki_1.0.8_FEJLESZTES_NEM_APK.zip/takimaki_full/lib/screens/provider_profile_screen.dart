import '../services/workflow_store.dart';

import "dart:convert";

import "package:flutter/material.dart";
import "package:shared_preferences/shared_preferences.dart";

import "../utils/profile_photo_loader.dart";
import "../theme.dart";
import "../widgets/branded_background.dart";

class ProviderProfileScreen extends StatefulWidget {
  const ProviderProfileScreen({super.key});
  @override
  State<ProviderProfileScreen> createState() => _S();
}

class _S extends State<ProviderProfileScreen> {
  ImageProvider? _photo;
  int _success = 0;
  String _name = "";
  String _bio = "";
  double _rating = 0;
  int _ratingCount = 0;
  List<String> _services = [];
  String _availability = "09:00–18:00";
  String _city = 'Budapest';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await WorkflowStore.refreshRatingSummary('provider');
    final prefs = await SharedPreferences.getInstance();
    final p = await ProfilePhotoLoader.loadAny(role: 'provider');
    if (!mounted) return;
    setState(() {
      _photo = p;
      _success = prefs.getInt("provider_success_count") ?? 0;
      final first =
          prefs.getString("provider_first_name") ??
          prefs.getString("customer_first_name") ??
          prefs.getString("registration_first_name") ??
          "";
      final last =
          prefs.getString("provider_last_name") ??
          prefs.getString("customer_last_name") ??
          prefs.getString("registration_last_name") ??
          "";
      _name = [last, first].where((e) => e.trim().isNotEmpty).join(" ");
      _bio = prefs.getString("provider_bio") ?? "";
      _city =
          prefs.getString('provider_city') ??
          prefs.getString('profile_city') ??
          'Budapest';
      _rating = prefs.getDouble("provider_rating") ?? 0;
      _ratingCount = prefs.getInt("provider_rating_count") ?? 0;
      final rawServices = prefs.getString("provider_services") ?? "[]";
      try {
        final decoded = (json.decode(rawServices) as List)
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        _services = decoded
            .map((item) => item["name"]?.toString() ?? "")
            .where((name) => name.isNotEmpty)
            .toSet()
            .toList();
      } catch (_) {
        _services = [];
      }
      final from = prefs.getString("provider_wd_from") ?? "09:00";
      final to = prefs.getString("provider_wd_to") ?? "18:00";
      _availability = "$from–$to";
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Szolgáltató profil'),
      actions: [
        IconButton(
          tooltip: 'Értesítések',
          onPressed: () => Navigator.pushNamed(context, '/work_notifications'),
          icon: const Icon(Icons.notifications_none_rounded),
        ),
        IconButton(
          tooltip: 'Beállítások',
          onPressed: () => Navigator.pushNamed(context, '/settings'),
          icon: const Icon(Icons.settings_outlined),
        ),
        IconButton(
          tooltip: 'Szerepváltás',
          onPressed: () => Navigator.pushNamedAndRemoveUntil(
            context,
            '/role_select',
            (route) => false,
          ),
          icon: const Icon(Icons.swap_horiz),
        ),
      ],
    ),
    body: BrandedBackground(
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      gradient: takiProfileGradient,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: takiTeal.withValues(alpha: .18),
                          blurRadius: 16,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(3),
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                              child: ProfileAvatar(
                                background: _photo,
                                radius: 30,
                                childWhenEmpty: const Icon(
                                  Icons.person,
                                  size: 32,
                                  color: takiNavy,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _name.isEmpty ? 'Szolgáltató' : _name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    _services.isEmpty
                                        ? 'Add meg a szolgáltatásaidat'
                                        : _services.take(2).join(' • '),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 13,
                                      height: 1.2,
                                    ),
                                  ),
                                  if (_bio.isNotEmpty) ...[
                                    const SizedBox(height: 3),
                                    Text(
                                      _bio,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12,
                                        height: 1.2,
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 5),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.location_on_outlined,
                                        size: 14,
                                        color: Colors.white,
                                      ),
                                      const SizedBox(width: 3),
                                      Expanded(
                                        child: Text(
                                          '$_city • $_availability',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                            height: 1.2,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _ProviderStat(
                                icon: Icons.star_rounded,
                                value: _success < 5 || _rating == 0
                                    ? '–'
                                    : _rating.toStringAsFixed(1),
                                label: 'értékelés',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _ProviderStat(
                                icon: Icons.verified_outlined,
                                value: '$_success',
                                label: 'sikeres munka',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _ProviderStat(
                                icon: Icons.chat_bubble_outline,
                                value: '$_ratingCount',
                                label: 'vélemény',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Material(
                    color: takiOrange,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () =>
                          Navigator.pushNamed(context, '/provider/requests'),
                      child: const Padding(
                        padding: EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Icon(
                              Icons.notifications_active_outlined,
                              size: 28,
                              color: takiNavy,
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Új megkeresések',
                                    style: TextStyle(
                                      color: takiNavy,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  SizedBox(height: 2),
                                  Text(
                                    'Válassz munkát és küldj ajánlatot',
                                    style: TextStyle(
                                      color: takiNavy,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.arrow_forward_rounded,
                              color: takiNavy,
                              size: 22,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Card(
                    color: takiMint,
                    child: ListTile(
                      leading: const Icon(Icons.calendar_month),
                      title: const Text('Naptár'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/calendar',
                        arguments: 'provider',
                      ),
                    ),
                  ),
                  const Text(
                    'Szolgáltatói eszközök',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                      color: takiNavy,
                    ),
                  ),
                  const SizedBox(height: 8),
                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: _ProviderMenu(
                            icon: Icons.design_services_outlined,
                            title: 'Szolgáltatásaim',
                            color: takiMint,
                            onTap: () async {
                              await Navigator.pushNamed(
                                context,
                                '/provider/services',
                              );
                              await _load();
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _ProviderMenu(
                            icon: Icons.assignment_outlined,
                            title: 'Munkáim',
                            color: takiYellowSoft,
                            onTap: () => Navigator.pushNamed(
                              context,
                              '/provider/all_orders',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Card(
                    color: takiMint,
                    child: ListTile(
                      leading: const Icon(Icons.report_outlined),
                      title: const Text('Saját hibajegyek'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/problem_tickets',
                        arguments: 'provider',
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: _ProviderMenu(
                            icon: Icons.chat_bubble_outline,
                            title: 'Üzenetek',
                            color: takiYellowSoft,
                            onTap: () => Navigator.pushNamed(
                              context,
                              '/provider/messages',
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _ProviderMenu(
                            icon: Icons.person_outline,
                            title: 'Profil szerkesztése',
                            color: takiMint,
                            onTap: () async {
                              await Navigator.pushNamed(
                                context,
                                '/provider/edit_profile',
                              );
                              await _load();
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

class _ProviderStat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _ProviderStat({
    required this.icon,
    required this.value,
    required this.label,
  });
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: .16),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 17, color: takiOrange),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70, fontSize: 11),
        ),
      ],
    ),
  );
}

class _ProviderMenu extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;
  const _ProviderMenu({
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => Material(
    color: color,
    borderRadius: BorderRadius.circular(20),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 94),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(icon, color: takiNavy, size: 25),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: takiNavy,
                    size: 20,
                  ),
                ],
              ),
              const SizedBox(height: 9),
              Text(
                title,
                style: const TextStyle(
                  color: takiNavy,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
