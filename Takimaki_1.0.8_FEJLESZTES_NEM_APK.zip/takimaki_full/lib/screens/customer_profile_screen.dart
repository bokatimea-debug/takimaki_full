import "package:flutter/material.dart";
import "package:shared_preferences/shared_preferences.dart";

import "../utils/profile_photo_loader.dart";
import "../services/local_marketplace_store.dart";
import "../services/sanctions_store.dart";
import "../theme.dart";
import "../widgets/branded_background.dart";

class CustomerProfileScreen extends StatefulWidget {
  const CustomerProfileScreen({super.key});
  @override
  State<CustomerProfileScreen> createState() => _S();
}

class _S extends State<CustomerProfileScreen> {
  ImageProvider? _photo;
  String _name = "";
  String _bio = "";
  int _success = 0;
  double _rating = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final p = await ProfilePhotoLoader.loadAny(role: 'customer');
    final first =
        prefs.getString("customer_first_name") ??
        prefs.getString("registration_first_name") ??
        "";
    final last =
        prefs.getString("customer_last_name") ??
        prefs.getString("registration_last_name") ??
        "";
    if (!mounted) return;
    setState(() {
      _photo = p;
      _name = [last, first].where((e) => e.trim().isNotEmpty).join(" ");
      _bio = prefs.getString("customer_bio") ?? "";
      _success = prefs.getInt("customer_success_count") ?? 0;
      _rating = prefs.getDouble("customer_rating") ?? 0;
    });
  }

  Future<void> _newOrder() async {
    if (await SanctionsStore.isCustomerSuspended()) {
      final until = await SanctionsStore.customerSuspendedUntil();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("Fiók felfüggesztve"),
          content: Text(
            "Késői lemondások miatt ${until?.toLocal().toString().split(' ').first ?? ''}-ig nem adhatsz le új rendelést.",
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Rendben"),
            ),
          ],
        ),
      );
      return;
    }
    final allowed = await LocalMarketplaceStore.canCustomerCreateOrder();
    if (!mounted) return;
    if (allowed) {
      Navigator.pushNamed(context, "/customer/search");
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Előfizetés szükséges"),
        content: const Text(
          "A 3 hónapos ingyenes időszak lejárt. Új rendeléshez 3 000 Ft/hó megrendelői előfizetés szükséges.",
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/subscriptions');
            },
            child: const Text("Előfizetések"),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Rendben"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Megrendelő profil'),
      actions: [
        IconButton(
          tooltip: 'Beállítások',
          onPressed: () => Navigator.pushNamed(context, '/settings'),
          icon: const Icon(Icons.settings_outlined),
        ),
        IconButton(
          tooltip: 'Szerepváltás',
          onPressed: () => Navigator.pushNamedAndRemoveUntil(
            context,
            '/role_select',
            (route) => false,
          ),
          icon: const Icon(Icons.swap_horiz),
        ),
      ],
    ),
    body: BrandedBackground(
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      gradient: takiProfileGradient,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: takiTeal.withValues(alpha: .18),
                          blurRadius: 16,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(3),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: ProfileAvatar(
                            background: _photo,
                            radius: 30,
                            childWhenEmpty: const Icon(
                              Icons.person,
                              size: 32,
                              color: takiNavy,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _name.isEmpty ? 'Megrendelő' : _name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              if (_bio.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  _bio,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 13,
                                    height: 1.2,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: [
                                  _ProfilePill(
                                    icon: Icons.star_rounded,
                                    text: _rating == 0
                                        ? 'Új profil'
                                        : _rating.toStringAsFixed(1),
                                  ),
                                  _ProfilePill(
                                    icon: Icons.check_circle_outline,
                                    text: '$_success rendelés',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Material(
                    color: takiOrange,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      onTap: _newOrder,
                      borderRadius: BorderRadius.circular(20),
                      child: const Padding(
                        padding: EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Icon(Icons.add_rounded, size: 28, color: takiNavy),
                            SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Új rendelés',
                                    style: TextStyle(
                                      color: takiNavy,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  SizedBox(height: 2),
                                  Text(
                                    'Mondd el, miben kérsz segítséget',
                                    style: TextStyle(
                                      color: takiNavy,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.arrow_forward_rounded,
                              color: takiNavy,
                              size: 22,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Minden egy helyen',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                      color: takiNavy,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    color: takiMint,
                    child: ListTile(
                      leading: const Icon(Icons.calendar_month),
                      title: const Text('Naptár'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/calendar',
                        arguments: 'customer',
                      ),
                    ),
                  ),
                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: _MenuCard(
                            icon: Icons.receipt_long_outlined,
                            title: 'Rendeléseim',
                            color: takiMint,
                            onTap: () => Navigator.pushNamed(
                              context,
                              '/customer/orders',
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MenuCard(
                            icon: Icons.chat_bubble_outline_rounded,
                            title: 'Üzenetek',
                            color: takiYellowSoft,
                            onTap: () => Navigator.pushNamed(
                              context,
                              '/customer/messages',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: _MenuCard(
                            icon: Icons.person_outline_rounded,
                            title: 'Profil szerkesztése',
                            compact: true,
                            color: takiYellowSoft,
                            onTap: () async {
                              await Navigator.pushNamed(
                                context,
                                '/customer/edit_profile',
                              );
                              await _load();
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

class _ProfilePill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _ProfilePill({required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: .18),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: takiOrange),
        const SizedBox(width: 4),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
      ],
    ),
  );
}

class _MenuCard extends StatelessWidget {
  final bool compact;
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;
  const _MenuCard({
    this.compact = false,
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => Material(
    color: color,
    borderRadius: BorderRadius.circular(20),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: compact ? 56 : 94),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: compact
              ? Row(
                  children: [
                    Icon(icon, color: takiNavy, size: 25),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          color: takiNavy,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right_rounded,
                      color: takiNavy,
                      size: 20,
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Icon(icon, color: takiNavy, size: 25),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: takiNavy,
                          size: 20,
                        ),
                      ],
                    ),
                    const SizedBox(height: 9),
                    Text(
                      title,
                      style: const TextStyle(
                        color: takiNavy,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    ),
  );
}
