import '../widgets/taki_app_bar.dart';
import 'package:flutter/material.dart';

import '../services/local_marketplace_store.dart';
import '../theme.dart';
import '../widgets/branded_background.dart';

class CustomerOrdersScreen extends StatefulWidget {
  const CustomerOrdersScreen({super.key});
  @override
  State<CustomerOrdersScreen> createState() => _CustomerOrdersScreenState();
}

class _CustomerOrdersScreenState extends State<CustomerOrdersScreen> {
  List<Map<String, dynamic>> _orders = [];
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _orders = await LocalMarketplaceStore.customerOrders();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: TakiAppBar(title: const Text('Rendeléseim')),
    body: BrandedBackground(
      child: _orders.isEmpty
          ? const TakiEmptyState(
              icon: Icons.receipt_long_outlined,
              title: 'Még nincs rendelésed',
              text: 'Indíts új keresést, és a rendeléseid itt jelennek meg.',
            )
          : ListView.separated(
              padding: const EdgeInsets.all(18),
              itemCount: _orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final order = _orders[index];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: const CircleAvatar(
                      backgroundColor: takiMint,
                      child: Icon(Icons.receipt_long, color: takiTealDark),
                    ),
                    title: Text(
                      (order['service'] ?? order['title'] ?? 'Rendelés')
                          .toString(),
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${order['date'] ?? ''} ${order['time'] ?? ''}\n${order['status'] ?? 'Függőben'}',
                    ),
                    isThreeLine: true,
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.pushNamed(
                        context,
                        order['status'] == 'Függőben' ? '/offers' : '/order/details',
                        arguments: {...order, 'view_role': 'customer'},
                      );
                      await _load();
                    },
                  ),
                );
              },
            ),
    ),
  );
}
