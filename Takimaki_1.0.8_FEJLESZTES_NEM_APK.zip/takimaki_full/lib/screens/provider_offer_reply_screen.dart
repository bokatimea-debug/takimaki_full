import '../utils/public_name.dart';
import '../widgets/taki_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/local_marketplace_store.dart';
import '../widgets/branded_background.dart';

class ProviderOfferReplyScreen extends StatefulWidget {
  const ProviderOfferReplyScreen({super.key});
  @override
  State<ProviderOfferReplyScreen> createState() =>
      _ProviderOfferReplyScreenState();
}

class _ProviderOfferReplyScreenState extends State<ProviderOfferReplyScreen> {
  final _price = TextEditingController();
  final _note = TextEditingController();
  Map<String, dynamic> _request = {};
  bool _sending = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_request.isNotEmpty) return;
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Map) _request = Map<String, dynamic>.from(args);
  }

  @override
  void dispose() {
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final amount = int.tryParse(_price.text.replaceAll(' ', ''));
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Adj meg érvényes árat.')));
      return;
    }
    setState(() => _sending = true);
    try {
      await LocalMarketplaceStore.sendOffer(
        request: _request,
        price: amount,
        note: _note.text.trim(),
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } on StateError catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message)));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Az ajánlatot nem sikerült menteni. Próbáld újra.'),
        ),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: TakiAppBar(title: const Text('Ajánlat küldése')),
    body: SafeArea(
      top: false,
      child: BrandedBackground(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            SectionBadge(
              icon: Icons.request_quote,
              text: _request['service']?.toString() ?? 'Ajánlatkérés',
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      peerNameFor(_request, 'customer'),
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(_request['address']?.toString() ?? ''),
                    Text(
                      '${_request['date'] ?? ''}  ${_request['time'] ?? ''}',
                    ),
                    if ((_request['note'] ?? '').toString().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(_request['note'].toString()),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _price,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                labelText: 'Ajánlott ár (Ft)',
                prefixIcon: Icon(Icons.payments_outlined),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Üzenet a megrendelőnek (opcionális)',
                prefixIcon: Icon(Icons.chat_bubble_outline),
              ),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _sending ? null : _send,
              child: Text(_sending ? 'Küldés…' : 'Ajánlat elküldése'),
            ),
          ],
        ),
      ),
    ),
  );
}
