import 'package:flutter/material.dart';

import '../services/local_marketplace_store.dart';
import '../utils/work_schedule.dart';
import '../widgets/taki_app_bar.dart';
import '../theme.dart';

class WorkCalendarScreen extends StatefulWidget {
  const WorkCalendarScreen({super.key});
  @override
  State<WorkCalendarScreen> createState() => _WorkCalendarScreenState();
}

class _WorkCalendarScreenState extends State<WorkCalendarScreen> {
  DateTime _day = DateUtils.dateOnly(DateTime.now());
  bool _week = false;
  String _role = 'customer';
  List<Map<String, dynamic>> _works = [];
  bool _loaded = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_loaded) return;
    _loaded = true;
    _role = ModalRoute.of(context)?.settings.arguments == 'provider'
        ? 'provider'
        : 'customer';
    _load();
  }

  Future<void> _load() async {
    final works = _role == 'provider'
        ? await LocalMarketplaceStore.providerOrders()
        : await LocalMarketplaceStore.customerOrders();
    if (mounted)
      setState(
        () => _works = works
            .where((w) => WorkSchedule.active(w) || w['status'] == 'Teljesítve')
            .toList(),
      );
  }

  @override
  Widget build(BuildContext context) {
    final monday = _day.subtract(Duration(days: _day.weekday - 1));
    final items =
        _works
            .where((w) => DateUtils.isSameDay(WorkSchedule.start(w), _day))
            .toList()
          ..sort(
            (a, b) => WorkSchedule.start(a)!.compareTo(WorkSchedule.start(b)!),
          );
    return Scaffold(
      appBar: TakiAppBar(title: const Text('Naptár')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Havi nézet')),
                ButtonSegment(value: true, label: Text('Heti nézet')),
              ],
              selected: {_week},
              onSelectionChanged: (v) => setState(() => _week = v.single),
            ),
            if (!_week)
              CalendarDatePicker(
                initialDate: _day,
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
                onDateChanged: (d) => setState(() => _day = d),
              ),
            if (_week) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () => setState(
                      () => _day = _day.subtract(const Duration(days: 7)),
                    ),
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Text(
                    '${monday.month}.${monday.day}. – ${monday.add(const Duration(days: 6)).day}.',
                  ),
                  IconButton(
                    onPressed: () => setState(
                      () => _day = _day.add(const Duration(days: 7)),
                    ),
                    icon: const Icon(Icons.chevron_right),
                  ),
                ],
              ),
              Wrap(
                spacing: 6,
                children: List.generate(7, (i) {
                  final day = monday.add(Duration(days: i));
                  final count = _works
                      .where(
                        (w) => DateUtils.isSameDay(WorkSchedule.start(w), day),
                      )
                      .length;
                  return ChoiceChip(
                    selected: DateUtils.isSameDay(day, _day),
                    label: Text(
                      '${['H', 'K', 'Sze', 'Cs', 'P', 'Szo', 'V'][i]} ${day.day} ($count)',
                    ),
                    onSelected: (_) => setState(() => _day = day),
                  );
                }),
              ),
            ],
            const SizedBox(height: 12),
            Text(
              '${_day.year}.${_day.month}.${_day.day}.',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            if (items.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Erre a napra nincs elfogadott munka.'),
              ),
            for (final work in items)
              Card(
                color: takiMint,
                child: ListTile(
                  leading: const Icon(Icons.event_available),
                  title: Text(
                    '${work['time']} • ${work['service'] ?? work['title']}',
                  ),
                  subtitle: Text(
                    '${work['address']}\n${WorkSchedule.minutes(work)} perc • ${work['status']}',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  isThreeLine: true,
                  onTap: () async {
                    await Navigator.pushNamed(
                      context,
                      '/order/details',
                      arguments: {...work, 'view_role': _role},
                    );
                    await _load();
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
